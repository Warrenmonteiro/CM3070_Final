import unittest
from unittest.mock import patch, MagicMock, mock_open
import io
import csv
import os
import random
import math
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))
import evaluation

# Dummy classes to simulate traci.trafficlight Phase and Logic objects.
class DummyPhase:
    def __init__(self, state):
        self.state = state

class DummyLogic:
    def __init__(self, programID, type, phases):
        self.programID = programID
        self.type = type
        self.phases = phases


class TestEvaluation(unittest.TestCase):

    @patch('evaluation.simulate_traffic', return_value=(1.0, 2.0, 0.5, 100))
    @patch('evaluation.traci')
    def test_evaluate_individual_success(self, mock_traci, mock_simulate_traffic):
        # Setup: simulate two traffic lights, each with one phase.
        tls_ids = ["tls_1", "tls_2"]
        mock_traci.trafficlight.getIDList.return_value = tls_ids

        # Create a dummy phase and logic that will be returned for every traffic light.
        dummy_phase = DummyPhase("GrGr")
        dummy_logic = DummyLogic("prog1", "static", [dummy_phase])
        mock_traci.trafficlight.getAllProgramLogics.return_value = [dummy_logic]

        # To simulate the constructors used in evaluation.evaluate_individual,
        # we let traci.trafficlight.Phase and .Logic be dummy lambdas that just return a dict.
        mock_traci.trafficlight.Phase.side_effect = lambda duration, state, minDur, maxDur: {
            "duration": duration, "state": state, "min": minDur, "max": maxDur
        }
        mock_traci.trafficlight.Logic.side_effect = lambda programID, type, currentPhaseIndex, phases: {
            "programID": programID, "type": type, "currentPhaseIndex": currentPhaseIndex, "phases": phases
        }

        # Define a dummy individual with two gene values.
        individual = [10, 20]
        phase_info = {"dummy": "info"}
        seed = 42
        generation = 1
        individual_idx = 0

        # Call evaluate_individual
        result, config_data = evaluation.evaluate_individual(
            individual, phase_info, seed, generation, individual_idx
        )

        # Check that the simulation results (from our patched simulate_traffic) are returned.
        self.assertEqual(result, (1.0, 2.0, 0.5, 100))

        # Verify that the config_data contains the expected values.
        expected_config_data = {
            'generation': generation,
            'individual_idx': individual_idx,
            'seed': seed,
            'individual': individual,
            'phase_info': phase_info
        }
        self.assertEqual(config_data, expected_config_data)

        # Verify that traci.start was called with the proper command.
        expected_cmd = evaluation.SUMO_CMD + ["--seed", str(seed)]
        mock_traci.start.assert_called_with(expected_cmd)

        # Verify that traci.close was called.
        self.assertTrue(mock_traci.close.called)

    @patch('evaluation.traci')
    def test_evaluate_individual_exception(self, mock_traci):
        # Force traci.start to raise an Exception.
        mock_traci.start.side_effect = Exception("start error")

        individual = [10, 20]
        phase_info = {"dummy": "info"}
        seed = 42
        generation = 1
        individual_idx = 0

        result, config_data = evaluation.evaluate_individual(
            individual, phase_info, seed, generation, individual_idx
        )

        # When an exception is raised, the function should return (inf, inf, inf, 0) and config_data as None.
        self.assertEqual(result, (float('inf'), float('inf'), float('inf'), 0))
        self.assertIsNone(config_data)

    @patch('evaluation.simulate_traffic', return_value=(1.5, 2.5, 0.7, 150))
    @patch('evaluation.traci')
    @patch('evaluation.os.path.isfile', return_value=False)
    def test_evaluate_baseline_success(self, mock_isfile, mock_traci, mock_simulate_traffic):
        # Define test inputs.
        round_num = 1
        seed = 42
        timestamp = "testtimestamp"

        # Prepare a mock for open so that we can intercept file writing.
        m = mock_open()
        with patch("evaluation.open", m, create=True):
            result = evaluation.evaluate_baseline(round_num, seed, timestamp)

        # Check that the result from simulate_traffic is returned.
        self.assertEqual(result, (1.5, 2.5, 0.7, 150))

        # Verify that the CSV file was opened for appending.
        baseline_filename = evaluation.BASELINE_RESULTS_CSV + f"{timestamp}.csv"
        m.assert_called_with(baseline_filename, "a", newline='')

        # Verify that traci.start was called with the proper command.
        expected_cmd = evaluation.SUMO_CMD + ["--seed", str(seed)]
        mock_traci.start.assert_called_with(expected_cmd)

    @patch('evaluation.traci')
    def test_evaluate_baseline_exception(self, mock_traci):
        # Force traci.start to raise an Exception.
        mock_traci.start.side_effect = Exception("start error")

        round_num = 1
        seed = 42
        timestamp = "testtimestamp"

        result = evaluation.evaluate_baseline(round_num, seed, timestamp)
        self.assertEqual(result, (float('inf'), float('inf'), float('inf'), 0))


if __name__ == '__main__':
    unittest.main()