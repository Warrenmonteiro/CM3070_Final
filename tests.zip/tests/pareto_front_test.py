import unittest
import pandas as pd
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))
from pareto_front import find_pareto_front

class TestParetoFront(unittest.TestCase):
    def test_empty_dataframe(self):
        # Create an empty dataframe with the required columns.
        df = pd.DataFrame({
            "Vehicle_Wait_Time": [],
            "Emissions": [],
            "Ped_Safety": [],
            "Total_Cars": []
        })
        result = find_pareto_front(df)
        self.assertTrue(result.empty)

    def test_single_point(self):
        # A single-row dataframe should return the same row.
        df = pd.DataFrame({
            "Vehicle_Wait_Time": [10],
            "Emissions": [100],
            "Ped_Safety": [0.5],
            "Total_Cars": [50]
        })
        result = find_pareto_front(df)
        pd.testing.assert_frame_equal(result.reset_index(drop=True), df.reset_index(drop=True))

    def test_clear_dominance(self):
        # Row 0 clearly dominates Row 1.
        df = pd.DataFrame({
            "Vehicle_Wait_Time": [10, 12],
            "Emissions": [50, 55],
            "Ped_Safety": [0.3, 0.4],
            "Total_Cars": [100, 90]
        })
        result = find_pareto_front(df)
        expected = df.iloc[[0]]
        pd.testing.assert_frame_equal(result.reset_index(drop=True), expected.reset_index(drop=True))

    def test_no_dominance(self):
        # None of these rows dominate each other.
        df = pd.DataFrame({
            "Vehicle_Wait_Time": [10, 12, 11],
            "Emissions": [100, 90, 95],
            "Ped_Safety": [0.5, 0.6, 0.55],
            "Total_Cars": [50, 55, 60]
        })
        result = find_pareto_front(df)
        # All rows are expected in the Pareto front.
        pd.testing.assert_frame_equal(result.reset_index(drop=True), df.reset_index(drop=True))

    def test_mixed_dominance(self):
        # Mixed case:
        # Row 3: [8, 95, 0.45, 51] dominates rows 0 and 1, but does not dominate row 2: [9, 110, 0.6, 52]
        # Expected Pareto front: rows 2 and 3.
        df = pd.DataFrame({
            "Vehicle_Wait_Time": [10, 11, 9, 8],
            "Emissions": [100, 105, 110, 95],
            "Ped_Safety": [0.5, 0.55, 0.6, 0.45],
            "Total_Cars": [50, 48, 52, 51]
        })
        result = find_pareto_front(df)
        expected = df.iloc[[2, 3]]
        pd.testing.assert_frame_equal(result.reset_index(drop=True), expected.reset_index(drop=True))

    def test_tie_points(self):
        # Two identical points should both be considered non-dominated.
        df = pd.DataFrame({
            "Vehicle_Wait_Time": [10, 10],
            "Emissions": [100, 100],
            "Ped_Safety": [0.5, 0.5],
            "Total_Cars": [50, 50]
        })
        result = find_pareto_front(df)
        pd.testing.assert_frame_equal(result.reset_index(drop=True), df.reset_index(drop=True))

if __name__ == '__main__':
    unittest.main()