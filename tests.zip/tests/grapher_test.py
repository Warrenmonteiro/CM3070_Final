import os
import tempfile
import unittest
import pandas as pd
import matplotlib.pyplot as plt
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))
import grapher

class TestGrapher(unittest.TestCase):
    def test_get_baseline_best(self):
        # Create a temporary CSV file with baseline data.
        with tempfile.TemporaryDirectory() as tmpdirname:
            baseline_file = os.path.join(tmpdirname, "baseline_test.csv")
            data = {
                "Round": [1],
                "Seed": [42],
                "Vehicle_Wait_Time": [10.0],
                "Emissions": [20.0],
                "Ped_Safety": [0.8],
                "Total_Cars": [100]
            }
            df = pd.DataFrame(data)
            df.to_csv(baseline_file, index=False)

            # Call the function using our test file.
            baseline_best = grapher.get_baseline_best(baseline_file)

            # Check that the extracted metrics match what we provided.
            self.assertAlmostEqual(baseline_best["Vehicle_Wait_Time"], 10.0)
            self.assertAlmostEqual(baseline_best["Emissions"], 20.0)
            self.assertAlmostEqual(baseline_best["Ped_Safety"], 0.8)
            self.assertAlmostEqual(baseline_best["Total_Cars"], 100)

    def test_graph_pareto_data(self):
        # Use a fixed timestamp for file naming.
        timestamp = "testtimestamp"
        with tempfile.TemporaryDirectory() as tmpdirname:
            # Create temporary directories for baseline, traffic, evaluation, and graphs.
            baseline_dir = os.path.join(tmpdirname, "baseline")
            traffic_dir = os.path.join(tmpdirname, "traffic")
            evaluation_dir = os.path.join(tmpdirname, "evaluation")
            graphs_dir = os.path.join(tmpdirname, "graphs")
            os.makedirs(baseline_dir, exist_ok=True)
            os.makedirs(traffic_dir, exist_ok=True)
            os.makedirs(evaluation_dir, exist_ok=True)
            os.makedirs(graphs_dir, exist_ok=True)

            # Override module-level constants so grapher uses our temporary directories.
            grapher.BASELINE_RESULTS_CSV = os.path.join(baseline_dir, "baseline_results_")
            grapher.TRAFFIC_OPTIMIZATION_CSV = os.path.join(traffic_dir, "traffic_optimization_")
            grapher.EVALUATION_METRICS = os.path.join(evaluation_dir, "evaluation_metrics_")
            grapher.GRAPHS_FOLDER = graphs_dir

            # Create a baseline CSV file with the expected naming convention.
            baseline_data = {
                "Round": [1],
                "Seed": [42],
                "Vehicle_Wait_Time": [10.0],
                "Emissions": [20.0],
                "Ped_Safety": [0.8],
                "Total_Cars": [100]
            }
            df_baseline = pd.DataFrame(baseline_data)
            baseline_file = os.path.join(baseline_dir, f"baseline_results_{timestamp}.csv")
            df_baseline.to_csv(baseline_file, index=False)

            # Create a traffic optimization CSV file with multiple generations.
            traffic_data = {
                "Generation": [0, 1, 2],
                "Vehicle_Wait_Time": [12.0, 9.0, 11.0],
                "Emissions": [22.0, 18.0, 19.0],
                "Ped_Safety": [0.75, 0.80, 0.82],
                "Total_Cars": [90, 95, 98]
            }
            df_traffic = pd.DataFrame(traffic_data)
            traffic_file = os.path.join(traffic_dir, f"traffic_optimization_{timestamp}.csv")
            df_traffic.to_csv(traffic_file, index=False)

            # Create an evaluation metrics CSV file with one row.
            eval_data = {
                "Vehicle_Wait_Time": [8.0],
                "Emissions": [17.0],
                "Ped_Safety": [0.85],
                "Total_Cars": [100]
            }
            df_eval = pd.DataFrame(eval_data)
            eval_file = os.path.join(evaluation_dir, f"evaluation_metrics_{timestamp}.csv")
            df_eval.to_csv(eval_file, index=False)

            # Call the graphing function.
            grapher.graph_pareto_data(timestamp)

            # Verify that the expected plot files were created in the graphs folder.
            expected_files = [
                "Vehicle_Wait_Time_pareto_.png",
                "Emissions_pareto_.png",
                "Ped_Safety_pareto_.png",
                "Total_Cars_pareto_.png",
                "normalized_pareto.png"
            ]
            for filename in expected_files:
                filepath = os.path.join(graphs_dir, filename)
                self.assertTrue(os.path.exists(filepath), f"Missing file: {filename}")
                # Verify the file is not empty.
                self.assertTrue(os.path.getsize(filepath) > 0, f"File {filename} is empty.")

if __name__ == '__main__':
    unittest.main()