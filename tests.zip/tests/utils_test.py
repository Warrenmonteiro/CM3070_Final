import unittest
import os
import sys
from pathlib import Path
from unittest.mock import patch, mock_open, MagicMock
import unittest
import tempfile

# Add parent directory to Python path
sys.path.append(str(Path(__file__).parent.parent))

import utils
from config import MAIN_FOLDER
from utils import calculate_weather, log_traffic_light_configuration, clone_individual_with_new_index, load_phases_and_seed


class TestTrafficOptimizationUtils(unittest.TestCase):
    def setUp(self):
        # Common test data
        self.timestamp = "2025_02_04_120000"
        self.filename = MAIN_FOLDER +  f"traffic_light_configs_{self.timestamp}.csv"
        
    def tearDown(self):
        # Clean up any test files that might have been created
        if os.path.exists(self.filename):
            os.remove(self.filename)

    def test_calculate_weather_zero(self):
        """Test weather calculation at t=0"""
        result = calculate_weather(0)
        self.assertAlmostEqual(result, 0.8)  # 0.8 + 0.4 * sin(0) = 0.8 + 0

    def test_calculate_weather_quarter_period(self):
        """Test weather calculation at t=0.25 (quarter period)"""
        result = calculate_weather(0.25)
        self.assertAlmostEqual(result, 1.2)  # 0.8 + 0.4 * sin(π/2) = 0.8 + 0.4

    def test_calculate_weather_half_period(self):
        """Test weather calculation at t=0.5 (half period)"""
        result = calculate_weather(0.5)
        self.assertAlmostEqual(result, 0.8)  # 0.8 + 0.4 * sin(π) = 0.8 + 0

    def test_calculate_weather_full_period(self):
        """Test weather calculation at t=1.0 (full period)"""
        result = calculate_weather(1.0)
        self.assertAlmostEqual(result, 0.8)  # 0.8 + 0.4 * sin(2π) = 0.8 + 0

    def test_log_traffic_light_new_file(self):
        """Test logging when file doesn't exist"""
        individual = [30, 45, 20]
        phase_info = [
            ("TL1", 0),
            ("TL1", 1),
            ("TL2", 0)
        ]
        
        mock_csv_writer = MagicMock()
        
        with patch('os.path.isfile', return_value=False), \
             patch('builtins.open', mock_open()) as mock_file, \
             patch('csv.writer', return_value=mock_csv_writer):
                
            log_traffic_light_configuration(
                individual=individual,
                generation=1,
                individual_idx=0,
                seed=42,
                phase_info=phase_info,
                timestamp=self.timestamp
            )

            # Check if file was opened in append mode
            mock_file.assert_called_once_with(self.filename, 'a', newline='')
            
            # Verify the calls to writerow
            expected_calls = [
                # Header row
                [
                    "Generation", "IndividualIndex", "Seed",
                    "Phase_0_ID", "Phase_0",
                    "Phase_1_ID", "Phase_1",
                    "Phase_2_ID", "Phase_2"
                ],
                # Data row
                [1, 0, 42, "TL1", 30, "TL1", 45, "TL2", 20]
            ]
            
            self.assertEqual(mock_csv_writer.writerow.call_count, 2)
            mock_csv_writer.writerow.assert_has_calls([
                unittest.mock.call(expected_calls[0]),
                unittest.mock.call(expected_calls[1])
            ])

    def test_log_traffic_light_existing_file(self):
        """Test logging when file already exists"""
        individual = [30, 45]
        phase_info = [
            ("TL1", 0),
            ("TL1", 1)
        ]
        
        mock_csv_writer = MagicMock()
        
        with patch('os.path.isfile', return_value=True), \
             patch('builtins.open', mock_open()) as mock_file, \
             patch('csv.writer', return_value=mock_csv_writer):
                
            log_traffic_light_configuration(
                individual=individual,
                generation=2,
                individual_idx=1,
                seed=42,
                phase_info=phase_info,
                timestamp=self.timestamp
            )

            # Check if file was opened in append mode
            mock_file.assert_called_once_with(self.filename, 'a', newline='')
            
            # Verify only data row was written (no header)
            mock_csv_writer.writerow.assert_called_once_with(
                [2, 1, 42, "TL1", 30, "TL1", 45]
            )


# --- Dummy Setup for clone_individual_with_new_index ---

# Define a dummy individual class.
class DummyIndividual(list):
    def __init__(self, genes):
        super().__init__(genes)
        self.fitness = None
        self.index = None

# Define a dummy creator with an Individual method.
class DummyCreator:
    def Individual(self, genes):
        return DummyIndividual(genes)

# Monkey-patch the creator in the utils module.
utils.creator = DummyCreator()

class TestCloneIndividualWithNewIndex(unittest.TestCase):
    def test_clone_without_optional_attributes(self):
        # Create a dummy individual with only genes and fitness.
        original = DummyIndividual([1, 2, 3])
        original.fitness = [0.5]
        original.index = 10
        next_index = lambda: 100  # Simple function to return a new index.

        new_ind = clone_individual_with_new_index(original, next_index)

        # Check that the new individual is a new object with the same gene list.
        self.assertIsNot(new_ind, original)
        self.assertEqual(new_ind, original)
        self.assertEqual(new_ind.fitness, original.fitness)
        self.assertEqual(new_ind.index, 100)
        # Optional attributes should not be present.
        self.assertFalse(hasattr(new_ind, 'strategy'))
        self.assertFalse(hasattr(new_ind, 'best'))

    def test_clone_with_strategy(self):
        # Test when the original individual has a 'strategy' attribute.
        original = DummyIndividual([4, 5, 6])
        original.fitness = [0.8]
        original.index = 20
        original.strategy = "aggressive"
        next_index = lambda: 200

        new_ind = clone_individual_with_new_index(original, next_index)

        self.assertEqual(new_ind, original)
        self.assertEqual(new_ind.fitness, original.fitness)
        self.assertEqual(new_ind.index, 200)
        self.assertTrue(hasattr(new_ind, 'strategy'))
        self.assertEqual(new_ind.strategy, "aggressive")

    def test_clone_with_best(self):
        # Test when the original individual has 'best' and 'best_fitness' attributes.
        original = DummyIndividual([7, 8, 9])
        original.fitness = [0.3]
        original.index = 30
        original.best = [1, 2, 3]
        original.best_fitness = [0.2]
        next_index = lambda: 300

        new_ind = clone_individual_with_new_index(original, next_index)

        self.assertEqual(new_ind, original)
        self.assertEqual(new_ind.fitness, original.fitness)
        self.assertEqual(new_ind.index, 300)
        self.assertTrue(hasattr(new_ind, 'best'))
        self.assertEqual(new_ind.best, original.best)
        # Ensure that the best list is a copy and not the same object.
        self.assertIsNot(new_ind.best, original.best)
        self.assertEqual(new_ind.best_fitness, original.best_fitness)

class TestLoadPhasesAndSeed(unittest.TestCase):
    def write_csv(self, content):
        """Helper function to write CSV content to a temporary file and return the filename."""
        temp_file = tempfile.NamedTemporaryFile(delete=False, mode='w', suffix='.csv')
        temp_file.write(content)
        temp_file.close()
        return temp_file.name

    def test_load_single_phase(self):
        # CSV content with one row and two phases.
        csv_content = (
            "Generation,IndividualIndex,Seed,Phase_0_ID,Phase_0,Phase_1_ID,Phase_1\n"
            "1,42,999,A,10,B,20\n"
        )
        filename = self.write_csv(csv_content)
        try:
            config, seed, phase_order = load_phases_and_seed(1, 42, filename)
            expected_config = {"A": [10], "B": [20]}
            expected_phase_order = [("A", 0), ("B", 0)]
            self.assertEqual(config, expected_config)
            self.assertEqual(seed, 999)
            self.assertEqual(phase_order, expected_phase_order)
        finally:
            os.unlink(filename)

    def test_load_multiple_phases_same_tls(self):
        # CSV content where the same traffic light appears twice.
        csv_content = (
            "Generation,IndividualIndex,Seed,Phase_0_ID,Phase_0,Phase_1_ID,Phase_1,Phase_2_ID,Phase_2\n"
            "2,99,555,X,5,X,15,Y,25\n"
        )
        filename = self.write_csv(csv_content)
        try:
            config, seed, phase_order = load_phases_and_seed(2, 99, filename)
            expected_config = {"X": [5, 15], "Y": [25]}
            expected_phase_order = [("X", 0), ("X", 1), ("Y", 0)]
            self.assertEqual(config, expected_config)
            self.assertEqual(seed, 555)
            self.assertEqual(phase_order, expected_phase_order)
        finally:
            os.unlink(filename)

    def test_no_matching_row(self):
        # CSV content where no row matches the given generation/individual index.
        csv_content = (
            "Generation,IndividualIndex,Seed,Phase_0_ID,Phase_0\n"
            "1,42,1000,A,10\n"
        )
        filename = self.write_csv(csv_content)
        try:
            # Expect an IndexError because .iloc[0] will fail when no row is found.
            with self.assertRaises(IndexError):
                load_phases_and_seed(2, 42, filename)
        finally:
            os.unlink(filename)


if __name__ == '__main__':
    unittest.main()