import unittest
from unittest.mock import patch, MagicMock, mock_open
from pathlib import Path
import sys
import warnings
from deap import creator, base

sys.path.append(str(Path(__file__).parent.parent))
from optimizer import AHMOATrafficOptimizer

class TestAHMOATrafficOptimizer(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        """Set up any necessary test fixtures that are shared across test methods"""
        # Suppress DEAP warnings about recreating types
        warnings.filterwarnings(action='ignore', category=RuntimeWarning,
                              message='A class named .* has already been created')

    def setUp(self):
        """Set up test fixtures before each test method"""
        # Mock traci setup
        traci_patch = patch.multiple('traci',
            start=MagicMock(),
            close=MagicMock(),
            trafficlight=MagicMock(
                getIDList=MagicMock(return_value=['intersection1']),
                getAllProgramLogics=MagicMock(return_value=[
                    MagicMock(phases=[MagicMock(), MagicMock()])
                ])
            )
        )
        traci_patch.start()
        self.addCleanup(traci_patch.stop)
        
        # Initialize optimizer
        self.timestamp = "test_timestamp"
        self.optimizer = AHMOATrafficOptimizer(self.timestamp)
        
        # Create test individuals using the optimizer's DEAP setup
        self.test_individual = creator.Individual([30, 30])
        self.test_individual.fitness.values = (100, 100, 0.5, 0.5)

    def tearDown(self):
        """Clean up after each test method"""
        if hasattr(self.optimizer, 'pso_velocity'):
            delattr(self.optimizer, 'pso_velocity')

    def test_initialization(self):
        """Test if optimizer is initialized correctly"""
        self.assertEqual(self.optimizer.timestamp, "test_timestamp")
        self.assertEqual(len(self.optimizer.initial_strategies), 4)
        self.assertEqual(len(self.optimizer.active_strategies), 4)
        self.assertEqual(len(self.optimizer.strategy_success), 4)
        self.assertEqual(self.optimizer.current_phase, 0)

    def test_determine_phase(self):
        """Test phase determination based on generation progress"""
        test_cases = [
            (0, 100, 0),    # Start of optimization
            (24, 100, 0),   # Just before first threshold
            (25, 100, 1),   # At first threshold
            (49, 100, 1),   # Just before second threshold
            (50, 100, 2),   # At second threshold
            (74, 100, 2),   # Just before third threshold
            (75, 100, 3),   # At third threshold
            (100, 100, 3)   # End of optimization
        ]
        
        for gen, total, expected in test_cases:
            with self.subTest(generation=gen, total=total):
                self.assertEqual(
                    self.optimizer.determine_phase(gen, total),
                    expected,
                    f"Failed for generation {gen}/{total}"
                )

    @patch('csv.writer')
    def test_log_results(self, mock_csv_writer):
        """Test logging of results to CSV"""
        mock_writer = MagicMock()
        mock_csv_writer.return_value = mock_writer
        
        test_cases = [
            (1, 0, (100, 200, 0.5, 50), 'GA'),
            (2, 1, (150, 250, 0.6, 60), 'DE'),
            (3, 2, (200, 300, 0.7, 70), 'PSO')
        ]
        
        for gen, idx, results, strategy in test_cases:
            with self.subTest(generation=gen, strategy=strategy):
                with patch('builtins.open', mock_open()) as mock_file:
                    self.optimizer.log_results(gen, idx, results, strategy)
                    mock_writer.writerow.assert_called_with([gen, idx, strategy, *results])

    def test_distribute_individuals(self):
        """Test distribution of individuals across strategies"""
        population_sizes = [4, 8, 12]  # Test different population sizes
        
        for size in population_sizes:
            with self.subTest(population_size=size):
                population = [creator.Individual([30, 30]) for _ in range(size)]
                distribution = self.optimizer.distribute_individuals(population)
                
                # Check distribution properties
                self.assertEqual(len(distribution.keys()), len(self.optimizer.active_strategies))
                total_distributed = sum(len(inds) for inds in distribution.values())
                self.assertEqual(total_distributed, size)
                
                # Check strategy assignments
                for strategy, individuals in distribution.items():
                    self.assertTrue(all(hasattr(ind, 'strategy') for ind in individuals))
                    self.assertTrue(all(ind.strategy == strategy for ind in individuals))

    def test_update_strategies(self):
        """Test strategy elimination based on performance"""
        test_cases = [
            {
                'success': {'GA': 10, 'DE': 5, 'PSO': 2, 'LS': 1},
                'usage': {'GA': 20, 'DE': 20, 'PSO': 20, 'LS': 20},
                'phase_thresholds': [0.25, 0.50, 0.75],
                'generation': 60,  # This should trigger phase 2
                'expected_eliminated': 'LS'
            },
            {
                'success': {'GA': 1, 'DE': 10, 'PSO': 5, 'LS': 2},
                'usage': {'GA': 20, 'DE': 20, 'PSO': 20, 'LS': 20},
                'phase_thresholds': [0.25, 0.50, 0.75],
                'generation': 80,  # This should trigger phase 3
                'expected_eliminated': ['LS', 'GA']  # Both should be eliminated by this phase
            }
        ]
        
        for case in test_cases:
            with self.subTest(case=case):
                # Reset optimizer state
                self.optimizer = AHMOATrafficOptimizer(self.timestamp)
                self.optimizer.phase_thresholds = case['phase_thresholds']
                self.optimizer.strategy_success = case['success']
                self.optimizer.strategy_usage = case['usage']
                self.optimizer.current_phase = 0
                
                self.optimizer.update_strategies(case['generation'], 100)
                
                if isinstance(case['expected_eliminated'], list):
                    for strategy in case['expected_eliminated']:
                        self.assertNotIn(strategy, self.optimizer.active_strategies)
                        self.assertIn(strategy, self.optimizer.eliminated_strategies)
                else:
                    self.assertNotIn(case['expected_eliminated'], self.optimizer.active_strategies)
                    self.assertIn(case['expected_eliminated'], self.optimizer.eliminated_strategies)

    def test_strategy_operations(self):
        """Test all strategy operations"""
        strategies = ['GA', 'PSO', 'LS']  # Test DE separately
        group_sizes = [1, 4, 8]  # Test different group sizes
        
        # Set up global best for PSO
        self.optimizer.global_best = creator.Individual([20, 20])
        self.optimizer.global_best.fitness.values = (90, 90, 0.6, 0.6)
        
        for strategy in strategies:
            for size in group_sizes:
                with self.subTest(strategy=strategy, group_size=size):
                    strategy_group = [creator.Individual([25, 25]) for _ in range(size)]
                    # Add fitness values for PSO
                    for ind in strategy_group:
                        ind.fitness.values = (100, 100, 0.5, 0.5)
                    
                    offspring = self.optimizer.apply_strategy_operations(strategy_group, strategy)
                    
                    # Common checks for all strategies
                    self.assertEqual(len(offspring), len(strategy_group))
                    self.assertTrue(all(isinstance(ind, creator.Individual) for ind in offspring))
                    self.assertTrue(all(all(5 <= x <= 60 for x in ind) for ind in offspring))
                    
                    # Strategy-specific checks
                    if strategy == 'PSO':
                        self.assertTrue(hasattr(self.optimizer, 'pso_velocity'))

    def test_DE_strategy(self):
        """Test Differential Evolution strategy separately"""
        # Only test with sufficient population sizes
        group_sizes = [4, 8]
        
        for size in group_sizes:
            with self.subTest(group_size=size):
                strategy_group = []
                for i in range(size):
                    # Create different individuals
                    ind = creator.Individual([20 + i, 30 + i])
                    ind.fitness.values = (100, 100, 0.5, 0.5)
                    strategy_group.append(ind)
                
                with patch('random.sample') as mock_sample:
                    # Ensure random.sample returns different individuals
                    mock_sample.return_value = [
                        creator.Individual([10, 20]),
                        creator.Individual([30, 40]),
                        creator.Individual([50, 60])
                    ]
                    
                    offspring = self.optimizer.apply_strategy_operations(strategy_group, 'DE')
                    
                    self.assertEqual(len(offspring), len(strategy_group))
                    self.assertTrue(all(isinstance(ind, creator.Individual) for ind in offspring))
                    self.assertTrue(all(all(5 <= x <= 60 for x in ind) for ind in offspring))
                    
                    # Verify offspring are different from parents
                    self.assertNotEqual(offspring[0], strategy_group[0])

if __name__ == '__main__':
    import sys
    sys.argv.extend(['-v'])  # Add verbosity flag to command line arguments
    unittest.main()