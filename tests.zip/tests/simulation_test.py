import os
import random
import tempfile
import unittest
from io import StringIO
import sys
import numpy as np
import pandas as pd
from pathlib import Path


sys.path.append(str(Path(__file__).parent.parent))
from simulation import simulate_traffic, run_simulation

# --- Fake traci and weather implementations ---

# Fake traffic light API.
class FakeTrafficLight:
    def __init__(self):
        self.phase_duration_calls = {}

    def getPhase(self, tls_id):
        # Always return phase 0.
        return 0

    def setPhaseDuration(self, tls_id, duration):
        self.phase_duration_calls.setdefault(tls_id, []).append(duration)


# Fake vehicle API.
class FakeVehicle:
    def __init__(self):
        # Use a single vehicle with constant properties.
        self.vehicles = {
            "veh1": {"waiting_time": 2.0, "CO2": 1.0, "position": (0.0, 0.0), "speed": 10.0}
        }

    def getIDList(self):
        return list(self.vehicles.keys())

    def getWaitingTime(self, veh_id):
        return self.vehicles[veh_id]["waiting_time"]

    def getCO2Emission(self, veh_id):
        return self.vehicles[veh_id]["CO2"]

    def getPosition(self, veh_id):
        return self.vehicles[veh_id]["position"]

    def getSpeed(self, veh_id):
        return self.vehicles[veh_id]["speed"]

    def setSpeed(self, veh_id, speed):
        self.vehicles[veh_id]["speed"] = speed

    def setSpeedFactor(self, veh_id, factor):
        # Dummy implementation.
        pass

    def setImperfection(self, veh_id, imperfection):
        # Dummy implementation.
        pass


# Fake person API.
class FakePerson:
    def getIDList(self):
        # For these tests, we simulate no pedestrians.
        return []

    def getPosition(self, person_id):
        return (0.0, 0.0)


# Fake simulation API.
class FakeSimulation:
    def __init__(self, total_steps):
        self.step = 0
        self.total_steps = total_steps

    def getMinExpectedNumber(self):
        # Return a positive number until the simulation has run for total_steps.
        if self.step < self.total_steps:
            return 1
        else:
            return 0

    def getArrivedIDList(self):
        # Simulate that no vehicles arrive.
        return []

    def increment(self):
        self.step += 1


# Fake traci module that bundles our fake APIs.
class FakeTraci:
    def __init__(self, duration):
        self.duration = duration
        self.trafficlight = FakeTrafficLight()
        self.vehicle = FakeVehicle()
        self.person = FakePerson()
        self.simulation = FakeSimulation(duration)

    def simulationStep(self):
        # Increment simulation step.
        self.simulation.increment()

    def start(self, sumoCmd):
        # Dummy start: do nothing.
        pass

    def close(self):
        # Dummy close: do nothing.
        pass


# Fake weather function: always returns 1.0.
def fake_calculate_weather(ratio):
    return 1.0


# --- Test Suite ---

class TestTrafficSimulation(unittest.TestCase):

    def setUp(self):
        # Use a simulation duration that ensures at least two measurements (every 50 steps).
        self.duration = 100
        # Create a fake traci instance.
        self.fake_traci = FakeTraci(self.duration)

        # Patch the traci and weather functions in the simulation module.
        # (Assuming simulation.py imports them as "import traci" and "from utils import calculate_weather")
        import simulation
        self.sim_module = simulation
        self.original_traci = simulation.traci
        simulation.traci = self.fake_traci

        self.original_calculate_weather = simulation.calculate_weather
        simulation.calculate_weather = fake_calculate_weather

        # To avoid unpredictable branches in simulate_traffic,
        # force random.random() to always return 1.0 so that no extra behavior triggers.
        self.original_random = random.random
        random.random = lambda: 1.0

    def tearDown(self):
        # Restore the original functions.
        self.sim_module.traci = self.original_traci
        self.sim_module.calculate_weather = self.original_calculate_weather
        random.random = self.original_random

    def test_simulate_traffic_without_fixed_timings(self):
        # Run simulation without any fixed traffic light timings.
        avg_wait, avg_emissions, ped_safety, vehicles_completed = simulate_traffic(self.duration)

        # Every 50 steps (i.e. at step 0 and step 50) the simulation records vehicle metrics.
        # With our fake vehicle, waiting time = 2.0 and CO2 = 1.0.
        # Total wait time = 2.0 + 2.0 = 4.0, total emissions = 1.0 + 1.0 = 2.0.
        # vehicles_completed remains 0 so we use max(0,1)=1 in the denominator.
        self.assertAlmostEqual(avg_wait, 4.0)
        self.assertAlmostEqual(avg_emissions, 2.0)
        self.assertEqual(ped_safety, 1.0)
        self.assertEqual(vehicles_completed, 0)

    def test_simulate_traffic_with_fixed_timings(self):
        # Provide a simple fixed timings dictionary.
        fixed_timings = {"tls1": [10, 20]}

        avg_wait, avg_emissions, ped_safety, vehicles_completed = simulate_traffic(
            self.duration, fixed_timings=fixed_timings
        )

        # Check that setPhaseDuration was called for traffic light "tls1" on every step.
        # Since FakeTrafficLight.getPhase always returns 0, each call should use timings[0] which is 10.
        calls = self.fake_traci.trafficlight.phase_duration_calls.get("tls1", [])
        self.assertEqual(len(calls), self.duration)
        self.assertTrue(all(duration == 10 for duration in calls))

        # The simulation metrics should be the same as in the previous test.
        self.assertAlmostEqual(avg_wait, 4.0)
        self.assertAlmostEqual(avg_emissions, 2.0)
        self.assertEqual(ped_safety, 1.0)

    def test_run_simulation(self):
        # Create a temporary directory to hold our fake CSV files.
        with tempfile.TemporaryDirectory() as tmpdirname:
            # Create a dummy CSV for traffic light timings.
            # The CSV must contain at least the following columns: "Seed", "Phase_0_ID", "Phase_0"
            timings_csv_content = "Seed,Phase_0_ID,Phase_0\n42,tls1,10\n"
            timings_csv_path = os.path.join(tmpdirname, "timings.csv")
            with open(timings_csv_path, "w") as f:
                f.write(timings_csv_content)

            # Define the expected output file for evaluation metrics.
            # Note: run_simulation resets the metrics_csv path to EVALUATION_METRICS + f"{timestamp}.csv"
            # So with timestamp "timings", the metrics file will be tmpdirname/timings.csv.
            expected_metrics_csv = os.path.join(tmpdirname, "timings.csv")

            # Patch the configuration paths in the simulation module so that when run_simulation
            # appends a timestamp and ".csv", it points to our temporary files.
            self.sim_module.FINAL_TRAFFIC_LIGHT_TIMINGS = os.path.join(tmpdirname, "")
            self.sim_module.EVALUATION_METRICS = os.path.join(tmpdirname, "")

            # Use a timestamp that matches our timings CSV file.
            timestamp = "timings"  # so that timings CSV = tmpdirname/timings.csv

            # Run the simulation.
            run_simulation(timestamp, GUI=False, metrics_csv="dummy")

            # Check that the metrics CSV was written and has the expected columns and values.
            metrics_df = pd.read_csv(expected_metrics_csv)
            expected_columns = {"Vehicle_Wait_Time", "Emissions", "Ped_Safety", "Total_Cars"}
            self.assertTrue(expected_columns.issubset(set(metrics_df.columns)))
            # Based on our fake simulation:
            # Total waiting time = 4.0, total emissions = 2.0, ped safety = 1.0, and no vehicles completed.
            self.assertAlmostEqual(metrics_df.loc[0, "Vehicle_Wait_Time"], 4.0)
            self.assertAlmostEqual(metrics_df.loc[0, "Emissions"], 2.0)
            self.assertAlmostEqual(metrics_df.loc[0, "Ped_Safety"], 1.0)
            self.assertEqual(metrics_df.loc[0, "Total_Cars"], 0)


if __name__ == "__main__":
    unittest.main()