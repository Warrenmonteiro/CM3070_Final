import unittest
from unittest.mock import patch, mock_open, call
import numpy as np
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))
# Import the module under test.
import rl_op
from rl_op import TrafficLightRLAgent, run_rl_simulation

# Dummy progress bar to simulate tqdm behavior in tests.
class DummyProgressBar:
    def __init__(self, total, **kwargs):
        self.total = total
    def update(self, n):
        pass
    def set_postfix_str(self, s):
        pass
    def __iter__(self):
        return iter(range(self.total))
    def __enter__(self):
        return self
    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

# --- Tests for the TrafficLightRLAgent class ---
class TestTrafficLightRLAgent(unittest.TestCase):

    @patch('traci.trafficlight.getPhase')
    @patch('traci.trafficlight.getControlledLanes')
    @patch('traci.lane.getLastStepHaltingNumber')
    @patch('traci.simulation.getTime')
    @patch('traci.person.getWaitingTime')
    @patch('traci.person.getIDList')
    def test_get_state(self, mock_person_getIDList, mock_person_getWaitingTime,
                       mock_simulation_getTime, mock_lane_getLastStepHaltingNumber,
                       mock_tl_getControlledLanes, mock_tl_getPhase):
        mock_tl_getPhase.return_value = 0
        mock_tl_getControlledLanes.return_value = ["lane1", "lane2"]
        mock_lane_getLastStepHaltingNumber.return_value = 2
        mock_simulation_getTime.return_value = 1000
        mock_person_getIDList.return_value = []
        agent = TrafficLightRLAgent("tl1", [30, 40])
        state = agent.get_state()
        expected_weather = 0.8 + 0.4 * np.sin(2 * np.pi * 1)
        self.assertEqual(state, (0, 4, round(expected_weather, 2), 0))

    def test_choose_action_exploit(self):
        agent = TrafficLightRLAgent("tl1", [30, 40])
        agent.epsilon = 0
        test_state = (0, 0, 0, 0)
        for action in agent.action_space:
            agent.q_table[(test_state, action)] = 10
        best_action = (0, 0)
        agent.q_table[(test_state, best_action)] = 20
        with patch('random.choice', return_value=best_action):
            chosen_action = agent.choose_action(test_state)
            self.assertEqual(chosen_action, best_action)

    def test_update_q_value(self):
        agent = TrafficLightRLAgent("tl1", [30, 40])
        state = (0, 0, 0, 0)
        action = (0, 0)
        next_state = (1, 1, 1, 1)
        agent.alpha = 0.5
        agent.gamma = 0.9
        agent.q_table[(state, action)] = 0
        for a in agent.action_space:
            agent.q_table[(next_state, a)] = 5
        agent.update_q_value(state, action, reward=10, next_state=next_state)
        self.assertAlmostEqual(agent.q_table[(state, action)], 7.25)

    def test_apply_action(self):
        agent = TrafficLightRLAgent("tl1", [30, 40])
        agent.apply_action((0, 5))
        self.assertEqual(agent.phases[0], 35)
        agent.phases[0] = 5
        agent.apply_action((0, -10))
        self.assertEqual(agent.phases[0], 5)
        agent.phases[0] = 120
        agent.apply_action((0, 10))
        self.assertEqual(agent.phases[0], 120)

    @patch('traci.trafficlight.setPhaseDuration')
    @patch('traci.trafficlight.getPhase', return_value=0)
    def test_update_simulation(self, mock_getPhase, mock_setPhaseDuration):
        agent = TrafficLightRLAgent("tl1", [30, 40])
        agent.update_simulation()
        mock_setPhaseDuration.assert_called_with("tl1", 30)

# --- Tests for the run_rl_simulation function ---
@patch('traci.simulation.getTime', return_value=1000)
@patch('traci.lane.getLastStepHaltingNumber', return_value=2)
@patch('traci.trafficlight.getControlledLanes', return_value=["lane1"])
@patch('rl_op.load_phases_and_seed')
@patch('traci.start')
@patch('traci.simulationStep')
@patch('traci.simulation.getMinExpectedNumber')
@patch('traci.close')
@patch('traci.trafficlight.getPhase', return_value=0)
@patch('traci.trafficlight.setPhaseDuration')
@patch('traci.vehicle.getIDList', return_value=[])
@patch('traci.person.getIDList', return_value=[])
@patch('traci.simulation.getArrivedIDList', return_value=[])
class TestRunRLSimulation(unittest.TestCase):
    def test_run_rl_simulation(self, 
                               mock_getArrivedIDList,
                               mock_person_getIDList,
                               mock_vehicle_getIDList,
                               mock_setPhaseDuration,
                               mock_getPhase,
                               mock_close,
                               mock_getMinExpectedNumber,
                               mock_simulationStep,
                               mock_start,
                               mock_load_phases_and_seed,
                               mock_getControlledLanes,
                               mock_getLastStepHaltingNumber,
                               mock_getTime):
        config_dict = {"tl1": [30, 40]}
        seed = 123
        phase_order = [("tl1", 0), ("tl1", 1)]
        mock_load_phases_and_seed.return_value = (config_dict, seed, phase_order)
        with patch('rl_op.DURATION', 3):
            mock_getMinExpectedNumber.side_effect = [1, 0]
            with patch('rl_op.tqdm', side_effect=lambda *args, **kwargs: DummyProgressBar(kwargs.get('total', 0))):
                m = mock_open()
                with patch('builtins.open', m):
                    rl_op.run_rl_simulation(generation=0, individual=0, timestamp="test")
                    self.assertTrue(mock_start.called)
                    self.assertTrue(mock_close.called)
                    final_timings_file = rl_op.FINAL_TRAFFIC_LIGHT_TIMINGS + "test.csv"
                    m.assert_any_call(final_timings_file, "w", newline="")

if __name__ == '__main__':
    unittest.main()